class DataSource(object):
    def emitInstrumentUpdate(self):
        raise NotImplementedError
